package com.example.uol_transport_desk;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ProblemActivity extends AppCompatActivity {

    TextView tvGreeting;
    EditText etDriverPhone, etEmail;
    Button btnCallDriver, btnSendEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_problem);

        tvGreeting = findViewById(R.id.tvGreeting);
        etDriverPhone = findViewById(R.id.etDriverPhone);
        etEmail = findViewById(R.id.etEmail);
        btnCallDriver = findViewById(R.id.btnCallDriver);
        btnSendEmail = findViewById(R.id.btnSendEmail);

        String name = getIntent().getStringExtra(
                MainActivity.EXTRA_STUDENT_NAME
        );

        if (name == null || name.trim().isEmpty()) {
            name = "Student";
        }

        tvGreeting.setText(
                "Hello, " + name + "! Tell us what went wrong."
        );

        btnCallDriver.setOnClickListener(v -> {
            String number = etDriverPhone.getText()
                    .toString().trim();

            if (!number.matches("03[0-9]{9}")) {
                etDriverPhone.setError(
                        "Enter an 11-digit number starting with 03"
                );
                etDriverPhone.requestFocus();
                return;
            }

            Intent intent = new Intent(
                    Intent.ACTION_DIAL,
                    Uri.parse("tel:" + number)
            );

            MainActivity.openIntent(this, intent);
        });

        btnSendEmail.setOnClickListener(v -> {
            String email = etEmail.getText()
                    .toString().trim();

            if (email.isEmpty() ||
                    !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {

                etEmail.setError(
                        "Please enter a valid email address"
                );
                etEmail.requestFocus();
                return;
            }

            Intent intent = new Intent(
                    Intent.ACTION_SENDTO,
                    Uri.parse("mailto:" + email)
            );

            MainActivity.openIntent(this, intent);
        });
    }
}

